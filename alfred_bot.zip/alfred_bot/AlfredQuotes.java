import java.util.Date;

public class AlfredQuotes {
    


    public String basicGreeting() {
        // You do not need to code here, this is an example method
        return "Hello, lovely to see you. How are you?";
    }
    


    // public String guestGreeting(String name) {
    // YOUR CODE HERE
    // return String.format("Hello, %s. Lovely to see you.", name);
    // }

        // return "place holder for guest greeting return string";
    // }
    


    // Ninja Bonus:
    // return greeting with day period (morning, afternoon, or evening)
    public String guestGreeting(String name, String dayPeriod) {
        return String.format("Good %s, %s. Lovely to see you.", dayPeriod, name);
    }



    public String dateAnnouncement() {
    // YOUR CODE HERE
        return String.format("It is currently %s", new Date());
    }

    // return "place holder for date announcement return string";
    // }
    


    public String respondBeforeAlexis(String conversation) {
    // YOUR CODE HERE
    // The -1 is just a way to verify Alexis or Alfred was called - per the given solution
        if (conversation.indexOf("Alexis") > -1) {
            return "Right away, sir. She certainly isn't sophisticated enough for that.";
        }

        if (conversation.indexOf("Alfred") > -1) {
            return "At your service. As you wish, naturally.";
        }

        return "Right. And with that I shall retire.";
    }

    // return "for snarky response return string";
    // }



	// Sensei Version of greeting:
    // Instead of a string for the day period, write the overloaded method with no parameters, and use a Date object to determine the day period.



    // Sensei Bonus:
    // Write your own AlfredQuote method using any of the String methods you have learned! For example maybe he sometimes yells when he's angry..

}   